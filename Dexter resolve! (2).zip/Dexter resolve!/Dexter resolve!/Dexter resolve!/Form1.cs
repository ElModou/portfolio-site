﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace Dexter_resolve_
{
    public partial class Form1 : Form
    {
        private List<Caso> casi = new List<Caso>();

        public Form1()
        {
            InitializeComponent();
            // Popola la combo una sola volta!
            comboBoxAnalista.Items.AddRange(new string[] { "Dexter", "Debra", "Angel", "Masuka" });
            comboBoxAnalista.DropDownStyle = ComboBoxStyle.DropDownList;
            AggiornaGriglia();
        }

        private void AggiornaGriglia()
        {
            dataGridViewCasi.DataSource = null;
            dataGridViewCasi.DataSource = casi;
        }

        private void btnAggiungi_Click(object sender, EventArgs e)
        {
            // Validazione base
            if (txtId.Text.Trim() == "" || txtNomeSospetto.Text.Trim() == "" ||
                txtTipoProva.Text.Trim() == "" || comboBoxAnalista.SelectedIndex == -1)
            {
                MessageBox.Show("Compila tutti i campi!");
                return;
            }

            int id;
            if (!int.TryParse(txtId.Text.Trim(), out id))
            {
                MessageBox.Show("L'ID deve essere un numero intero!");
                return;
            }

            var caso = new Caso
            {
                Id = id,
                NomeSospetto = txtNomeSospetto.Text.Trim(),
                DataCaso = dateTimePickerData.Value,
                TipoProva = txtTipoProva.Text.Trim(),
                Analista = comboBoxAnalista.SelectedItem.ToString()
            };
            casi.Add(caso);
            AggiornaGriglia();
            PulisciCampi();
        }

        private void btnModifica_Click(object sender, EventArgs e)
        {
            if (dataGridViewCasi.SelectedRows.Count > 0)
            {
                int index = dataGridViewCasi.SelectedRows[0].Index;
                if (index >= 0 && index < casi.Count)
                {
                    int id;
                    if (!int.TryParse(txtId.Text.Trim(), out id))
                    {
                        MessageBox.Show("L'ID deve essere un numero intero!");
                        return;
                    }
                    var caso = casi[index];
                    caso.Id = id;
                    caso.NomeSospetto = txtNomeSospetto.Text.Trim();
                    caso.DataCaso = dateTimePickerData.Value;
                    caso.TipoProva = txtTipoProva.Text.Trim();
                    caso.Analista = comboBoxAnalista.SelectedItem.ToString();

                    AggiornaGriglia();
                    PulisciCampi();
                }
            }
        }

        private void btnElimina_Click(object sender, EventArgs e)
        {
            if (dataGridViewCasi.SelectedRows.Count > 0)
            {
                int index = dataGridViewCasi.SelectedRows[0].Index;
                if (index >= 0 && index < casi.Count)
                {
                    casi.RemoveAt(index);
                    AggiornaGriglia();
                    PulisciCampi();
                }
            }
        }

        private void dataGridViewCasi_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewCasi.SelectedRows.Count > 0)
            {
                int index = dataGridViewCasi.SelectedRows[0].Index;
                if (index >= 0 && index < casi.Count)
                {
                    var caso = casi[index];
                    txtId.Text = caso.Id.ToString();
                    txtNomeSospetto.Text = caso.NomeSospetto;
                    dateTimePickerData.Value = caso.DataCaso;
                    txtTipoProva.Text = caso.TipoProva;
                    comboBoxAnalista.SelectedItem = caso.Analista;
                }
            }
        }

        private void PulisciCampi()
        {
            txtId.Text = "";
            txtNomeSospetto.Text = "";
            txtTipoProva.Text = "";
            comboBoxAnalista.SelectedIndex = -1;
            dateTimePickerData.Value = DateTime.Today;
        }

        private void btnSalva_Click(object sender, EventArgs e)
        {
            try
            {
                using (var sw = new StreamWriter("casi.csv"))
                {
                    foreach (var caso in casi)
                    {
                        // Data in formato yyyy-MM-dd
                        sw.WriteLine($"{caso.Id},{caso.NomeSospetto},{caso.DataCaso:yyyy-MM-dd},{caso.TipoProva},{caso.Analista}");
                    }
                }
                MessageBox.Show("Casi salvati!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore nel salvataggio: " + ex.Message);
            }
        }

        private void btnCarica_Click(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists("casi.csv"))
                {
                    casi.Clear();
                    foreach (var line in File.ReadAllLines("casi.csv"))
                    {
                        var parts = line.Split(',');
                        if (parts.Length >= 5)
                        {
                            int id;
                            DateTime data;
                            if (!int.TryParse(parts[0], out id)) continue;
                            if (!DateTime.TryParse(parts[2], out data)) continue;
                            casi.Add(new Caso
                            {
                                Id = id,
                                NomeSospetto = parts[1],
                                DataCaso = data,
                                TipoProva = parts[3],
                                Analista = parts[4]
                            });
                        }
                    }
                    AggiornaGriglia();
                }
                else
                {
                    MessageBox.Show("File casi.csv non trovato!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore nel caricamento: " + ex.Message);
            }
        }
    }
}