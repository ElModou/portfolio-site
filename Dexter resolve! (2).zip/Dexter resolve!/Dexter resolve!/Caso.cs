﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dexter_resolve_
{
    public class Caso
    {
        public int Id { get; set; }
        public string NomeSospetto { get; set; }
        public DateTime DataCaso { get; set; }
        public string TipoProva { get; set; }
        public string Analista { get; set; }
        public string Note { get; set; }
    }
}
